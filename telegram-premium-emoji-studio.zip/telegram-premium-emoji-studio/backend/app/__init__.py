"""Telegram Premium Emoji Studio — backend application package."""

__version__ = "1.0.0"
